import json, boto3
client = boto3.client('lambda')
response = client.create_function(
    FunctionName='KinesisLam',
    Runtime='python3.6',
    Role='arn:aws:iam::791903720429:role/mylambdakinDynamoS3',
    Handler='KinesisLam.lambda_handler',
    Code= {'ZipFile': open(r'C:\Users\shumondal\PycharmProjects\Lambda\mylambda.zip', 'rb').read() })
