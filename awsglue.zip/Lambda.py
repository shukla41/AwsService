import json, boto3
client = boto3.client('lambda')
response = client.create_function(
    FunctionName='LambdaToGlueExecution',
    Runtime='python3.6',
    Role='arn:aws:lambda:us-east-1:083645284229:function:mylam',
    Handler='mylambda.lambda_handler',
    Code= {'ZipFile': open(r'C:\Users\shumondal\PycharmProjects\Lambda\mylambda.zip', 'rb').read() })